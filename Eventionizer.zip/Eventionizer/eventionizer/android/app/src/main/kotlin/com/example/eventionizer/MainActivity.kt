package com.example.eventionizer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
