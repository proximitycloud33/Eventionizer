class Event {
  final String name;
  final String date;
  final String time;
  final String description;

  Event({
    required this.name,
    required this.date,
    required this.time,
    required this.description,
  });
}

List<Event> eventList = [
  Event(
    name: 'Liburan ke bandung Farm House',
    date: 'Sunday, September 22',
    time: '17:26',
    description:
        'Berada di jalur utama Bandung-Lembang, Farm House menjadi objek wisata yang tidak pernah sepi pengunjung. Selain karena letaknya strategis, kawasan ini juga menghadirkan nuansa wisata khas Eropa. Semua itu diterapkan dalam bentuk spot swafoto Instagramable',
  ),
  Event(
      name: 'Anime conference',
      date: 'Sunday, October 1',
      time: '12:00',
      description:
          'Lorem ipsum it amet, molestie a nibh. Ut euismod nisl arcu, sed placerat nulla volutpat aliquet. Ut id convallis nisl. Ut mauris leo, lacinia sed elit id, sagittis rhoncus odio. Pellentesque sapien libero, lobortis a placerat et, maleszuada sit amet dui. Nam sem sapien, congue eu rutrum nec, pellentesque eget ligula'),
  Event(
      name: 'Hangout With Friends',
      date: 'Monday, November 2',
      time: '12:00',
      description:
          'Lorem ipsum it amet, molestie a nibh. Ut euismod nisl arcu, sed placerat nulla volutpat aliquet. Ut id convallis nisl. Ut mauris leo, lacinia sed elit id, sagittis rhoncus odio. Pellentesque sapien libero, lobortis a placerat et, maleszuada sit amet dui. Nam sem sapien, congue eu rutrum nec, pellentesque eget ligula'),
];
