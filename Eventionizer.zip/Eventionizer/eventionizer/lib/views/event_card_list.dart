import 'package:eventionizer/model/event_model.dart';
import 'package:eventionizer/screens/detail_event_screen.dart';
import 'package:flutter/material.dart';
import 'package:eventionizer/utils/theme.dart';

class EventCardList extends StatefulWidget {
  final List<Event> event;
  const EventCardList({
    Key? key,
    required this.event,
  }) : super(key: key);

  @override
  State<EventCardList> createState() => _EventCardListState();
}

class _EventCardListState extends State<EventCardList> {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(left: 20, right: 20),
      child: ListView.separated(
        itemCount: eventList.length,
        itemBuilder: (context, index) {
          final Event event = eventList[index];
          return Card(
            color: MyTheme.colors.surfaceVariant,
            elevation: 0,
            child: InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return DetailEventScreen(
                        event: event,
                        index: index,
                      );
                    },
                  ),
                ).then((value) => setState(() {}));
              },
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      event.name,
                      style:
                          MyTheme.titleLarge(MyTheme.colors.onSurface, context),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      '${event.date} ${event.time}',
                      style:
                          MyTheme.bodyMedium(MyTheme.colors.onSurface, context),
                    ),
                    const SizedBox(height: 7),
                    Text(
                      event.description,
                      style: MyTheme.bodyMedium(
                          MyTheme.colors.onSurfaceVariant, context),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ),
              ),
            ),
          );
        },
        separatorBuilder: (context, index) => const SizedBox(
          height: 15,
        ),
      ),
    );
  }
}
