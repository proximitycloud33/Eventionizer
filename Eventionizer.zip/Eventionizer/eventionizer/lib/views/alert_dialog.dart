import 'package:flutter/material.dart';

class MyAlertDialog extends StatelessWidget {
  final String title;
  final String content;
  final String confirmText;
  final String cancelText;
  final VoidCallback? confirmCallback;
  final VoidCallback? cancelCallback;
  const MyAlertDialog(
      {Key? key,
      required this.title,
      required this.content,
      required this.confirmText,
      required this.cancelText,
      this.confirmCallback,
      this.cancelCallback})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(title),
      content: Text(content),
      actions: [
        TextButton(
          onPressed: cancelCallback,
          child: Text(cancelText),
        ),
        TextButton(
          onPressed: confirmCallback,
          child: Text(confirmText),
        )
      ],
    );
  }
}
