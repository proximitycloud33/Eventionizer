import 'package:flutter/material.dart';

class MyTextField extends StatefulWidget {
  final TextEditingController controller;
  final TextInputAction textInputAction;
  final String label;
  final int? maxline;
  final int? minline;
  final VoidCallback? onTapCallback;
  final IconButton iconButton;
  final bool readOnly;
  final String hintText;
  final FloatingLabelBehavior? floatingLabelBehavior;
  const MyTextField({
    Key? key,
    required this.controller,
    required this.textInputAction,
    this.maxline,
    this.minline,
    this.label = '',
    this.onTapCallback,
    required this.iconButton,
    this.readOnly = false,
    this.hintText = '',
    this.floatingLabelBehavior,
  }) : super(key: key);

  @override
  State<MyTextField> createState() => _MyTextFieldState();
}

class _MyTextFieldState extends State<MyTextField> {
  @override
  Widget build(BuildContext context) {
    return TextField(
      readOnly: widget.readOnly,
      controller: widget.controller,
      textInputAction: widget.textInputAction,
      maxLines: widget.maxline,
      minLines: widget.minline,
      onTap: widget.onTapCallback,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        label: Text(widget.label),
        floatingLabelBehavior: widget.floatingLabelBehavior,
        suffixIcon: widget.iconButton,
        hintText: widget.hintText,
        // contentPadding: EdgeInsets.all(32.0)
        // isDense: true,
      ),
    );
  }
}
