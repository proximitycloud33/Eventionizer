import 'dart:async';

import 'package:eventionizer/model/event_model.dart';
import 'package:eventionizer/screens/detail_event_web_screen.dart';
import 'package:eventionizer/utils/theme.dart';
import 'package:flutter/material.dart';

class EventCardGrid extends StatefulWidget {
  final int gridCount;
  const EventCardGrid({Key? key, required this.gridCount}) : super(key: key);

  @override
  State<EventCardGrid> createState() => _EventCardGridState();
}

StreamController streamController = StreamController.broadcast();

class _EventCardGridState extends State<EventCardGrid> {
  ScrollController scrollController = ScrollController();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20),
      child: Scrollbar(
        controller: scrollController,
        thumbVisibility: true,
        child: StreamBuilder(
          stream: streamController.stream,
          builder: (context, snapshot) => GridView.builder(
            physics: const ScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: widget.gridCount,
              childAspectRatio: 1 / 0.45,
              mainAxisSpacing: 15,
              crossAxisSpacing: 15,
            ),
            itemCount: eventList.length,
            itemBuilder: (context, index) {
              final Event event = eventList[index];
              return Card(
                color: MyTheme.colors.surfaceVariant,
                elevation: 0,
                child: InkWell(
                  onTap: () {
                    Navigator.push(
                        context,
                        DialogRoute(
                          context: context,
                          builder: (context) {
                            return DetailEventWebScreen(
                                event: event, index: index);
                          },
                        )).then((value) => setState(() {}));
                  },
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          event.name,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: MyTheme.titleLarge(
                              MyTheme.colors.onSurface, context),
                        ),
                        const SizedBox(height: 7),
                        Text(
                          '${event.date} ${event.time}',
                          style: MyTheme.bodyMedium(
                              MyTheme.colors.onSurface, context),
                        ),
                        const SizedBox(height: 7),
                        Text(
                          event.description,
                          style: MyTheme.bodyMedium(
                              MyTheme.colors.onSurfaceVariant, context),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
