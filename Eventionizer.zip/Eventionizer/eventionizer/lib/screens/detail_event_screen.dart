import 'package:eventionizer/model/event_model.dart';
import 'package:eventionizer/screens/form_event_screen.dart';
import 'package:eventionizer/utils/theme.dart';
import 'package:eventionizer/views/alert_dialog.dart';
import 'package:flutter/material.dart';

class DetailEventScreen extends StatefulWidget {
  final Event event;
  final int index;
  const DetailEventScreen({Key? key, required this.event, required this.index})
      : super(key: key);

  @override
  State<DetailEventScreen> createState() => _DetailEventScreenState();
}

class _DetailEventScreenState extends State<DetailEventScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          tooltip: 'Back',
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text('Detail Event'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            tooltip: 'Edit',
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) {
                    return FormEventScreen(
                      title: 'Edit',
                      event: widget.event,
                      index: widget.index,
                    );
                  },
                ),
              ).then((value) => setState(() {}));
            },
          ),
        ],
      ),
      body: Container(
        margin: const EdgeInsets.only(left: 15, top: 20, right: 15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              widget.event.name,
              style: MyTheme.titleLarge(MyTheme.colors.onSurface, context),
            ),
            const SizedBox(height: 20),
            Card(
              elevation: 0,
              color: MyTheme.colors.surfaceVariant,
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 15),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxHeight: 25),
                  child: Row(
                    children: [
                      const Spacer(flex: 1),
                      Text(
                        widget.event.date,
                        style: MyTheme.bodyMedium(
                          MyTheme.colors.onSurfaceVariant,
                          context,
                        ),
                      ),
                      const Spacer(flex: 1),
                      VerticalDivider(
                        // width: 20,
                        thickness: 1,
                        color: MyTheme.colors.outline,
                      ),
                      const Spacer(flex: 2),
                      Text(
                        widget.event.time,
                        style: MyTheme.bodyMedium(
                          MyTheme.colors.onSurfaceVariant,
                          context,
                        ),
                      ),
                      const Spacer(flex: 2),
                    ],
                  ),
                ),
              ),
            ),
            const SizedBox(
              height: 20,
            ),
            Text(
              widget.event.description,
              style: MyTheme.bodyLarge(MyTheme.colors.onSurface, context),
            )
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              return MyAlertDialog(
                title: 'Event Selesai?',
                content:
                    'Event yang telah selesai akan dihapus pada daftar dan tidak bisa dikembalikan lagi.',
                confirmText: 'Ok',
                cancelText: 'Cancel',
                cancelCallback: () {
                  Navigator.pop(context);
                },
                confirmCallback: () {
                  eventList.removeAt(widget.index);
                  Navigator.popUntil(context, (route) => route.isFirst);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: const Text('Event Selesai'),
                      duration: const Duration(seconds: 2),
                      backgroundColor: MyTheme.colors.primary,
                    ),
                  );
                },
              );
            },
          );
        },
        icon: const Icon(Icons.done),
        label: const Text('Complete'),
      ),
    );
  }
}
