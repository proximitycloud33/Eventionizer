import 'package:eventionizer/model/event_model.dart';
import 'package:eventionizer/screens/form_event_screen.dart';
import 'package:eventionizer/views/event_card_grid.dart';
import 'package:eventionizer/views/event_card_list.dart';
import 'package:flutter/material.dart';

class EventScreen extends StatefulWidget {
  const EventScreen({Key? key}) : super(key: key);

  @override
  State<EventScreen> createState() => _EventScreenState();
}

class _EventScreenState extends State<EventScreen> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 20,
        title: Text('Eventionizer $size'),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          if (eventList.isEmpty) {
            return const Center(child: Text('Anda tidak memiliki event'));
          } else if (constraints.maxWidth < 810) {
            return EventCardList(event: eventList);
          } else if (constraints.maxWidth < 1200) {
            return const EventCardGrid(gridCount: 2);
          } else {
            return const EventCardGrid(gridCount: 3);
          }
        },
      ),
      floatingActionButton: FloatingActionButton.extended(
        icon: const Icon(Icons.add),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) {
                return const FormEventScreen(
                  title: 'Tambah',
                );
              },
            ),
          ).then((value) async {
            if (size > 800) {
              await Future.delayed(const Duration(seconds: 2));
              streamController.add(null);
            }
            setState(() {});
          });
        },
        label: const Text('Tambah Event'),
      ),
    );
  }
}
