import 'package:eventionizer/model/event_model.dart';
import 'package:eventionizer/views/alert_dialog.dart';
import 'package:eventionizer/views/text_field.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../utils/theme.dart';

class FormEventScreen extends StatefulWidget {
  final String title;
  final Event? event;
  final int index;
  const FormEventScreen(
      {Key? key, this.event, required this.title, this.index = 0})
      : super(key: key);

  @override
  State<FormEventScreen> createState() => _FormEventScreenState();
}

class _FormEventScreenState extends State<FormEventScreen> {
  late TextEditingController eventNameController;
  late TextEditingController dateController;
  late TextEditingController timeController;
  late TextEditingController descriptionController;
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  Future<DateTime?> selectDate(BuildContext context) async {
    return await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2050),
    );
  }

  Future<TimeOfDay?> selectTime(BuildContext context) async {
    return await showTimePicker(
      context: context,
      initialTime: TimeOfDay.now(),
    );
  }

  @override
  void initState() {
    super.initState();
    eventNameController = TextEditingController(text: widget.event?.name ?? '');
    dateController = TextEditingController(text: widget.event?.date ?? '');
    timeController = TextEditingController(text: widget.event?.time ?? '');
    descriptionController =
        TextEditingController(text: widget.event?.description ?? '');
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        FocusManager.instance.primaryFocus?.unfocus();
      },
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            onPressed: () {
              FocusManager.instance.primaryFocus?.unfocus();
              if (eventNameController.text.isNotEmpty ||
                  dateController.text.isNotEmpty ||
                  timeController.text.isNotEmpty ||
                  descriptionController.text.isNotEmpty) {
                showDialog(
                  context: context,
                  builder: (context) {
                    return MyAlertDialog(
                      title: 'Batalkan ${widget.title} Event?',
                      content:
                          'Apabila ada data yang telah dimasukan maka akan dihapus.',
                      confirmText: 'Confirm',
                      cancelText: 'Cancel',
                      cancelCallback: () => Navigator.pop(context),
                      confirmCallback: () =>
                          Navigator.popUntil(context, (route) => route.isFirst),
                    );
                  },
                );
              } else {
                Navigator.pop(context);
              }
            },
            icon: const Icon(Icons.close),
          ),
          title: Text('${widget.title} Event'),
          actions: [
            TextButton(
              child: const Text('Simpan'),
              onPressed: () {
                switch (widget.title) {
                  case 'Tambah':
                    if (eventNameController.text.isNotEmpty &&
                        descriptionController.text.isNotEmpty) {
                      final Event event = Event(
                          name: eventNameController.text,
                          date: dateController.text,
                          time: timeController.text,
                          description: descriptionController.text);
                      eventList.insert(0, event);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          backgroundColor: MyTheme.colors.primary,
                          content: Text(
                            'Event berhasil ditambahkan',
                            style: MyTheme.bodyMedium(
                              MyTheme.colors.onPrimary,
                              context,
                            ),
                          ),
                        ),
                      );
                      Navigator.popUntil(context, (route) => route.isFirst);
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          backgroundColor: MyTheme.colors.primary,
                          content: Text(
                            'Semua data harus disi',
                            style: MyTheme.bodyMedium(
                              MyTheme.colors.onPrimary,
                              context,
                            ),
                          ),
                        ),
                      );
                    }
                    break;
                  case 'Edit':
                    final Event event = Event(
                        name: eventNameController.text,
                        date: dateController.text,
                        time: timeController.text,
                        description: descriptionController.text);
                    eventList[widget.index] = event;
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        backgroundColor: MyTheme.colors.primary,
                        content: Text(
                          'Event berhasil di Edit',
                          style: MyTheme.bodyMedium(
                            MyTheme.colors.onPrimary,
                            context,
                          ),
                        ),
                      ),
                    );
                    Navigator.popUntil(context, (route) => route.isFirst);
                    break;
                  default:
                }
              },
            ),
          ],
        ),
        body: SingleChildScrollView(
          child: Container(
            margin: const EdgeInsets.only(left: 15, top: 20, right: 15),
            child: Column(
              children: [
                MyTextField(
                  controller: eventNameController,
                  textInputAction: TextInputAction.done,
                  label: 'Nama Event',
                  // hintText: 'Hello',
                  iconButton: IconButton(
                    splashRadius: 10,
                    onPressed: eventNameController.clear,
                    icon: const Icon(Icons.cancel_outlined),
                  ),
                ),
                const SizedBox(height: 20),
                MyTextField(
                  readOnly: true,
                  floatingLabelBehavior: FloatingLabelBehavior.never,
                  // hintText: 'Tanggal',
                  label: 'Tanggal',
                  controller: dateController,
                  textInputAction: TextInputAction.next,
                  onTapCallback: () async {
                    selectedDate = await selectDate(context);
                    FocusManager.instance.primaryFocus?.unfocus();
                    if (selectedDate != null) {
                      dateController.text =
                          DateFormat('EEEE, d MMMM').format(selectedDate!);
                    }
                  },
                  iconButton: IconButton(
                    splashRadius: 10,
                    onPressed: dateController.clear,
                    icon: const Icon(Icons.cancel_outlined),
                  ),
                ),
                const SizedBox(height: 20),
                MyTextField(
                  readOnly: true,
                  floatingLabelBehavior: FloatingLabelBehavior.never,
                  // hintText: 'Tanggal',
                  label: 'Waktu Mulai',
                  controller: timeController,
                  textInputAction: TextInputAction.next,
                  onTapCallback: () async {
                    selectedTime = await selectTime(context);
                    FocusManager.instance.primaryFocus?.unfocus();
                    if (selectedTime != null) {
                      // ignore: use_build_context_synchronously
                      timeController.text = selectedTime!.format(context);
                    }
                  },
                  iconButton: IconButton(
                    splashRadius: 10,
                    onPressed: timeController.clear,
                    icon: const Icon(Icons.cancel_outlined),
                  ),
                ),
                const SizedBox(
                  height: 20,
                ),
                MyTextField(
                  controller: descriptionController,
                  label: 'Deskripsi Event',
                  textInputAction: TextInputAction.done,
                  minline: 2,
                  maxline: null,
                  iconButton: IconButton(
                    splashRadius: 10,
                    onPressed: () {
                      if (descriptionController.text.isNotEmpty) {
                        showDialog(
                          context: context,
                          builder: (context) => MyAlertDialog(
                            title: 'Hapus Deskripsi?',
                            content:
                                'Deskripsi Event yang anda telah tuliskan akan dihapus dan tidak dapat dikembalikan lagi.',
                            confirmText: 'Confirm',
                            cancelText: 'Cancel',
                            confirmCallback: () {
                              descriptionController.clear();
                              Navigator.pop(context);
                            },
                            cancelCallback: () => Navigator.pop(context),
                          ),
                        );
                      }
                    },
                    icon: const Icon(Icons.cancel_outlined),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    eventNameController.dispose();
    dateController.dispose();
    timeController.dispose();
    descriptionController.dispose();
    super.dispose();
  }
}
