// import 'package:eventionizer/screens/form_event_screen.dart';
// import 'package:eventionizer/utils/theme.dart';
// import 'package:eventionizer/views/alert_dialog.dart';
import 'package:eventionizer/model/event_model.dart';
import 'package:eventionizer/screens/form_event_screen.dart';
import 'package:eventionizer/utils/theme.dart';
import 'package:eventionizer/views/alert_dialog.dart';
import 'package:flutter/material.dart';

class DetailEventWebScreen extends StatefulWidget {
  final Event event;
  final int index;
  const DetailEventWebScreen(
      {Key? key, required this.event, required this.index})
      : super(key: key);

  @override
  State<DetailEventWebScreen> createState() => _DetailEventWebScreenState();
}

class _DetailEventWebScreenState extends State<DetailEventWebScreen> {
  @override
  Widget build(BuildContext context) {
    final ScrollController scrollController = ScrollController();
    var height = MediaQuery.of(context).size.height * 0.85;
    var width = MediaQuery.of(context).size.width * 0.50;
    return AlertDialog(
      content: Container(
        width: width,
        height: height,
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 20),
        child: SingleChildScrollView(
          controller: scrollController,
          physics: const ScrollPhysics(),
          child: Column(
            // mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                widget.event.name,
                style: MyTheme.titleLarge(MyTheme.colors.onSurface, context),
              ),
              const SizedBox(height: 20),
              Card(
                elevation: 0,
                color: MyTheme.colors.surfaceVariant,
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxHeight: 25),
                    child: Row(
                      // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        const Spacer(flex: 1),
                        Text(
                          widget.event.date,
                          style: MyTheme.bodyMedium(
                            MyTheme.colors.onSurfaceVariant,
                            context,
                          ),
                        ),
                        const Spacer(flex: 2),
                        VerticalDivider(
                          // width: 20,
                          thickness: 1,
                          color: MyTheme.colors.outline,
                        ),
                        const Spacer(flex: 2),
                        Text(
                          widget.event.time,
                          style: MyTheme.bodyMedium(
                            MyTheme.colors.onSurfaceVariant,
                            context,
                          ),
                        ),
                        const Spacer(flex: 2),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                widget.event.description,
                style: MyTheme.bodyLarge(
                  MyTheme.colors.onSurface,
                  context,
                ),
              ),
            ],
          ),
        ),
      ),
      actions: [
        TextButton(
          child: const Text('Close'),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        TextButton(
          child: const Text('Edit'),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) {
                  return FormEventScreen(
                    title: 'Edit',
                    event: widget.event,
                    index: widget.index,
                  );
                },
              ),
            ).then((value) => setState(() {}));
          },
        ),
        TextButton(
          child: const Text('Complete'),
          onPressed: () {
            showDialog(
              context: context,
              builder: (context) {
                return MyAlertDialog(
                  title: 'Event Selesai?',
                  content:
                      'Event yang telah selesai akan dihapus pada daftar dan tidak bisa dikembalikan lagi.',
                  confirmText: 'Ok',
                  cancelText: 'Cancel',
                  cancelCallback: () {
                    Navigator.pop(context);
                  },
                  confirmCallback: () {
                    eventList.removeAt(widget.index);
                    Navigator.popUntil(context, (route) => route.isFirst);
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: const Text('Event Selesai'),
                        duration: const Duration(seconds: 2),
                        backgroundColor: MyTheme.colors.primary,
                      ),
                    );
                  },
                );
              },
            );
          },
        ),
      ],
    );
  }
}
