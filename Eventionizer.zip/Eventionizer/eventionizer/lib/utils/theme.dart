import 'package:flutter/material.dart';

/// class static tema untuk warna dan font. supaya tidak terlalu panjang saat mengganti style
class MyTheme {
  static final ColorScheme colors =
      ColorScheme.fromSeed(seedColor: const Color(0xAA94D1BE));

  static TextStyle? titleLarge(Color color, BuildContext context) =>
      Theme.of(context).textTheme.titleLarge?.copyWith(color: color);
  static TextStyle? titleMedium(Color color, BuildContext context) =>
      Theme.of(context).textTheme.titleMedium?.copyWith(color: color);
  static TextStyle? titleSmall(Color color, BuildContext context) =>
      Theme.of(context).textTheme.titleSmall?.copyWith(color: color);

  static TextStyle? bodyLarge(Color color, BuildContext context) =>
      Theme.of(context).textTheme.bodyLarge?.copyWith(color: color);
  static TextStyle? bodyMedium(Color color, BuildContext context) =>
      Theme.of(context).textTheme.bodyMedium?.copyWith(color: color);
  static TextStyle? bodySmall(Color color, BuildContext context) =>
      Theme.of(context).textTheme.bodySmall?.copyWith(color: color);
}
